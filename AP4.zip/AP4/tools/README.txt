en tools :
Pour organiser nos différentes tâches, nous utilisons le logiciel GanttProject.
Nous avons utiliser FileZila pour le serveur FTP, PostgreSQL pour le serveur de BDD et Nginx pour le serveur WEB. 
